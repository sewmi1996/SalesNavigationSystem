 // Initialize Firebase
  var config = {
    apiKey: "AIzaSyA995Q6cEiTRff2zxsdww5oRxfsR3pKfr8",
    authDomain: "salesmannavigati-1537527400892.firebaseapp.com",
    databaseURL: "https://salesmannavigati-1537527400892.firebaseio.com",
    projectId: "salesmannavigati-1537527400892",
    storageBucket: "",
    messagingSenderId: "456138819990"
  };
  firebase.initializeApp(config);
